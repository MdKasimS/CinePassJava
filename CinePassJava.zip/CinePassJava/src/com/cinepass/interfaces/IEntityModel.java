package com.cinepass.interfaces;

public interface IEntityModel {
    int getId();
}
