package com.cinepass.views;

import java.util.Scanner;
import com.cinepass.controllers.AuthController;

public class SignInView {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AuthController authController = new AuthController();

        System.out.print("Enter username: ");
        String username = scanner.nextLine().trim();  // Trim spaces

        System.out.print("Enter password: ");
        String password = scanner.nextLine().trim();

        if (authController.login(username, password)) {
            System.out.println("Login successful!");
        } else {
            System.out.println("Invalid credentials!");
        }

        scanner.close();
    }
}
