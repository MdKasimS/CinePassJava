package com.cinepass.controllers;

import com.cinepass.models.Auth;

public class AuthController {
    public boolean login(String username, String password) {
        Auth auth = new Auth(username, password);
        return auth.validate();
    }
}
