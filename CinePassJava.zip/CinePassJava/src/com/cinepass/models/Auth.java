package com.cinepass.models;

public class Auth {
    private String username;
    private String password;

    public Auth(String username, String password) {
        this.username = username.trim();  // Remove extra spaces
        this.password = password.trim();
    }

    public boolean validate() {
        // Debugging: Print entered values
        System.out.println("DEBUG: Entered Username: " + username);
        System.out.println("DEBUG: Entered Password: " + password);

        // Fix case sensitivity and trim spaces
        return "Gurjot".equalsIgnoreCase(username) && "Gurjot123".equals(password);
    }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username.trim(); }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password.trim(); }
}
