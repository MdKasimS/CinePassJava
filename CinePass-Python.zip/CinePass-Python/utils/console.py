import os

class Console:
    @staticmethod
    def write_line(text):
        print(text)
    
    @staticmethod
    def error(text):
        print(f"\033[91m{text}\033[0m")  # Prints in red color
    
    @staticmethod
    def clear():
        os.system('cls' if os.name == 'nt' else 'clear')