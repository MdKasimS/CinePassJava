from utils.console import Console

class StartView:
    def display(self):
        while True:
            Console.write_line("\nWelcome to CinePass!")
            Console.write_line("1. Home")
            Console.write_line("2. Sign Up")
            Console.write_line("3. Manage Tickets")
            Console.write_line("4. User Home")
            Console.write_line("5. User Management")
            Console.write_line("6. Account Settings")
            Console.write_line("7. Forgot Password")
            Console.write_line("10. Admin Home")
            Console.write_line("9. Exit")
            
            choice = input("Please enter your choice: ")
            if choice.isdigit():
                return int(choice)
            
            Console.write_line("⚠️ Invalid input. Please enter a number.")
