from utils.console import Console
from database.db_handler import DBHandler

class SignUpView:
    def __init__(self):
        self.db = DBHandler()

    def display(self):
        Console.clear()
        Console.write_line("\n📝 Sign Up")
        
        username = input("Enter a username: ")
        email = input("Enter your email: ")
        password = input("Enter a password: ")

        if self.db.add_user(username, password, email):
            Console.write_line("✅ Sign up successful! You can now log in.")
        else:
            Console.write_line("⚠️ Username already exists! Please try again.")

        input("Press Enter to return to the main menu...")
