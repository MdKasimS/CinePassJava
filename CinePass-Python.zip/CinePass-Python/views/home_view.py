from utils.console import Console

class HomeView:
    def display(self):
        while True:
            Console.clear()
            Console.write_line("\n🏠 Welcome to CinePass!")
            Console.write_line("1. Sign Up")
            Console.write_line("2. Manage Tickets")
            Console.write_line("3. User Home")
            Console.write_line("4. User Management (Admin)")
            Console.write_line("5. Account Settings")
            Console.write_line("6. Forgot Password")
            Console.write_line("7. Admin Home")
            Console.write_line("9. Exit")

            choice = input("Enter your choice: ")

            if choice == "1":
                return 2  # Navigate to SignUpView
            elif choice == "2":
                return 3  # Navigate to ManageTicketView
            elif choice == "3":
                return 4  # Navigate to UserHomeView
            elif choice == "4":
                return 5  # Navigate to UserManagementView
            elif choice == "5":
                return 6  # Navigate to AccountView
            elif choice == "6":
                return 7  # Navigate to ForgotPasswordView
            elif choice == "7":
                return 10  # Navigate to AdminHomeView
            elif choice == "9":
                Console.write_line("👋 Exiting CinePass...")
                exit(0)
            else:
                Console.write_line("⚠️ Invalid choice. Please try again.")
