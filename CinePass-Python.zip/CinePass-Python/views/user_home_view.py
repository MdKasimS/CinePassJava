from utils.console import Console

class UserHomeView:
    def display(self):
        while True:
            Console.clear()
            Console.write_line("\n🏡 User Home")
            Console.write_line("1. View Profile")
            Console.write_line("2. View Ticket History")
            Console.write_line("9. Back to Main Menu")

            choice = input("Enter your choice: ")

            if choice == "1":
                Console.write_line("👤 Displaying profile information...")
            elif choice == "2":
                Console.write_line("📜 Viewing ticket history...")
            elif choice == "9":
                break  # Go back to Main Menu
            else:
                Console.write_line("⚠️ Invalid choice. Please try again.")

        input("Press Enter to return...")
