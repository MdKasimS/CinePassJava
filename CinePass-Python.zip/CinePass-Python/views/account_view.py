from utils.console import Console
from database.db_handler import DBHandler

class AccountView:
    def __init__(self):
        self.db = DBHandler()

    def display(self):
        while True:
            Console.clear()
            Console.write_line("\n⚙️ Account Settings")
            Console.write_line("1. Update Email")
            Console.write_line("2. Change Password")
            Console.write_line("9. Back to Main Menu")

            choice = input("Enter your choice: ")

            if choice == "1":
                self.update_email()
            elif choice == "2":
                self.change_password()
            elif choice == "9":
                break  # Back to Main Menu
            else:
                Console.write_line("⚠️ Invalid choice. Please try again.")

        input("Press Enter to return...")

    def update_email(self):
        Console.clear()
        username = input("Enter your username: ")
        new_email = input("Enter your new email: ")

        if self.db.update_user(username, username, new_email):
            Console.write_line("✅ Email updated successfully!")
        else:
            Console.write_line("⚠️ User not found!")

    def change_password(self):
        Console.clear()
        username = input("Enter your username: ")
        new_password = input("Enter new password: ")

        hashed_password = self.db.hash_password(new_password)
        with sqlite3.connect(self.db.db_file) as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE users SET password = ? WHERE username = ?", (hashed_password, username))
            conn.commit()

        Console.write_line("✅ Password updated successfully!")
