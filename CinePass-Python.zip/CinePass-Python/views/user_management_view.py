from utils.console import Console
from database.db_handler import DBHandler

class UserManagementView:
    def __init__(self):
        self.db = DBHandler()  # Initialize DB connection

    def display(self):
        while True:
            Console.clear()
            Console.write_line("\n👤 User Management")
            Console.write_line("1. Add User")
            Console.write_line("2. Remove User")
            Console.write_line("3. View Users")
            Console.write_line("4. Update User Info")
            Console.write_line("9. Back to Admin Menu")

            choice = input("Enter your choice: ")

            if choice == "1":
                self.add_user()
            elif choice == "2":
                self.remove_user()
            elif choice == "3":
                self.view_users()
            elif choice == "4":
                self.update_user()
            elif choice == "9":
                break  # Exit back to Admin Menu
            else:
                Console.write_line("⚠️ Invalid choice. Please try again.")

    def add_user(self):
        Console.clear()
        Console.write_line("\n🆕 Add New User")
        username = input("Enter new username: ")
        email = input("Enter email: ")
        password = input("Enter password: ")
        is_admin = input("Is this user an admin? (yes/no): ").strip().lower() == "yes"

        if self.db.add_user(username, password, email, int(is_admin)):
            Console.write_line("✅ User added successfully!")
        else:
            Console.write_line("⚠️ Username already exists!")

        input("Press Enter to return to User Management...")

    def remove_user(self):
        Console.clear()
        Console.write_line("\n🗑 Remove User")
        username = input("Enter username to remove: ")

        if self.db.remove_user(username):
            Console.write_line("✅ User removed successfully!")
        else:
            Console.write_line("⚠️ User not found!")

        input("Press Enter to return to User Management...")

    def view_users(self):
        Console.clear()
        Console.write_line("\n📋 List of Users")
        users = self.db.get_all_users()

        if users:
            for user in users:
                role = "Admin" if user["is_admin"] else "User"
                Console.write_line(f"- {user['username']} ({role}), Email: {user['email']}")
        else:
            Console.write_line("⚠️ No users found!")

        input("Press Enter to return to User Management...")

    def update_user(self):
        Console.clear()
        Console.write_line("\n✏️ Update User Info")
        old_username = input("Enter the current username: ")
        new_username = input("Enter the new username: ")
        new_email = input("Enter the new email: ")

        if self.db.update_user(old_username, new_username, new_email):
            Console.write_line("✅ User information updated successfully!")
        else:
            Console.write_line("⚠️ User not found!")

        input("Press Enter to return to User Management...")
