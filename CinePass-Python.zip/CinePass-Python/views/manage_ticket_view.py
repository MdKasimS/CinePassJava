from utils.console import Console

class ManageTicketView:
    def display(self):
        while True:
            Console.clear()
            Console.write_line("\n🎟 Ticket Management")
            Console.write_line("1. Book Ticket")
            Console.write_line("2. Cancel Ticket")
            Console.write_line("3. View Tickets")
            Console.write_line("9. Back to Main Menu")

            choice = input("Enter your choice: ")

            if choice == "1":
                Console.write_line("✅ Ticket booked successfully!")
            elif choice == "2":
                Console.write_line("❌ Ticket canceled successfully!")
            elif choice == "3":
                Console.write_line("📄 Viewing tickets...")
            elif choice == "9":
                break  # Go back to Main Menu
            else:
                Console.write_line("⚠️ Invalid choice. Please try again.")

        input("Press Enter to return...")
