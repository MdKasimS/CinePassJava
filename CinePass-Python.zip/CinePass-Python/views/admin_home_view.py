from utils.console import Console
from views.user_management_view import UserManagementView

class AdminHomeView:
    def display(self):
        while True:  # Keep the admin menu running
            Console.clear()
            Console.write_line("\n👮‍♂️ Admin Home")
            Console.write_line("1. Manage Users")
            Console.write_line("2. View Reports")
            Console.write_line("9. Back to Main Menu")

            choice = input("Enter your choice: ")

            if choice == "1":
                user_management = UserManagementView()
                user_management.display()  # This now properly enters the User Management menu
            elif choice == "2":
                Console.write_line("📊 Viewing reports...")
                input("Press Enter to return...")
            elif choice == "9":
                break  # Exit back to the main menu
            else:
                Console.write_line("⚠️ Invalid choice. Please try again.")
