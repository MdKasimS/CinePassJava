import sqlite3
from utils.console import Console
from database.db_handler import DBHandler

class ForgotPasswordView:
    def __init__(self):
        self.db = DBHandler()

    def display(self):
        Console.clear()
        Console.write_line("\n🔑 Forgot Password")
        
        username = input("Enter your username: ")

        with sqlite3.connect(self.db.db_file) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT email FROM users WHERE username = ?", (username,))
            user = cursor.fetchone()

        if user:
            Console.write_line(f"📩 A password reset link has been sent to {user[0]} (simulated).")
        else:
            Console.write_line("⚠️ Username not found!")

        input("Press Enter to return to the main menu...")
