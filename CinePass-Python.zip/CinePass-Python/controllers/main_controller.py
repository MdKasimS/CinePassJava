from utils.console import Console
from views.start_view import StartView
from views.home_view import HomeView
from views.manage_ticket_view import ManageTicketView
from views.signup_view import SignUpView
from views.user_home_view import UserHomeView
from views.user_management_view import UserManagementView
from views.account_view import AccountView
from views.forgot_password_view import ForgotPasswordView
from views.admin_home_view import AdminHomeView

class MainController:
    def __init__(self):
        self.views = {
            1: HomeView(),
            2: SignUpView(),
            3: ManageTicketView(),
            4: UserHomeView(),
            5: UserManagementView(),
            6: AccountView(),
            7: ForgotPasswordView(),
            10: AdminHomeView(),
        }

    def run(self):
        while True:
            Console.clear()
            Console.write_line("\nWelcome to CinePass!")
            Console.write_line("1. Home")
            Console.write_line("2. Sign Up")
            Console.write_line("3. Manage Tickets")
            Console.write_line("4. User Home")
            Console.write_line("5. User Management")
            Console.write_line("6. Account Settings")
            Console.write_line("7. Forgot Password")
            Console.write_line("10. Admin Home")
            Console.write_line("9. Exit")
            
            choice = self.get_valid_choice()
            if choice == 9:
                Console.write_line("👋 Exiting CinePass. Goodbye!")
                break
            
            if choice in self.views:
                view = self.views[choice]
                view.display()
            else:
                Console.write_line("⚠️ Invalid choice. Please try again.")

    def get_valid_choice(self):
        while True:
            try:
                choice = int(input("Enter your choice: "))
                return choice
            except ValueError:
                Console.write_line("⚠️ Invalid input. Please enter a valid number.")
