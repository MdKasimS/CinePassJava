import json
import os
from utils.console import Console

class TicketController:
    def __init__(self, ticket_file="data/tickets.json"):
        self.ticket_file = ticket_file
        self.ensure_ticket_file()

    def ensure_ticket_file(self):
        if not os.path.exists(self.ticket_file):
            with open(self.ticket_file, "w") as file:
                json.dump({}, file)

    def book_ticket(self, user_id, movie, seat):
        try:
            with open(self.ticket_file, "r") as file:
                tickets = json.load(file)
        except (json.JSONDecodeError, FileNotFoundError):
            tickets = {}

        if user_id not in tickets:
            tickets[user_id] = []

        tickets[user_id].append({"movie": movie, "seat": seat})

        with open(self.ticket_file, "w") as file:
            json.dump(tickets, file)

        Console.write_line("✅ Ticket booked successfully!")