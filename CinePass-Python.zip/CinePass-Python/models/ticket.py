import json
import os

class Ticket:
    DATA_FILE = "data/tickets.json"

    def __init__(self, user, movie, seat):
        self.user = user
        self.movie = movie
        self.seat = seat

    def to_dict(self):
        return {"user": self.user, "movie": self.movie, "seat": self.seat}

    @classmethod
    def save_ticket(cls, ticket):
        tickets = cls.load_tickets()
        tickets.append(ticket.to_dict())
        cls.write_tickets(tickets)

    @classmethod
    def load_tickets(cls):
        if not os.path.exists(cls.DATA_FILE):
            return []
        with open(cls.DATA_FILE, "r") as file:
            return json.load(file)

    @classmethod
    def delete_ticket(cls, user, seat):
        tickets = cls.load_tickets()
        updated_tickets = [t for t in tickets if not (t["user"] == user and t["seat"] == seat)]
        cls.write_tickets(updated_tickets)
        return len(tickets) != len(updated_tickets)

    @classmethod
    def write_tickets(cls, tickets):
        os.makedirs(os.path.dirname(cls.DATA_FILE), exist_ok=True)
        with open(cls.DATA_FILE, "w") as file:
            json.dump(tickets, file, indent=4)

    @classmethod
    def list_user_tickets(cls, user):
        tickets = cls.load_tickets()
        return [t for t in tickets if t["user"] == user]
