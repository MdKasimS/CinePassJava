import sqlite3
import hashlib

class DBHandler:
    def __init__(self, db_file="database/cinepass.db"):
        """Initialize the database connection and create tables if needed"""
        self.db_file = db_file
        self.create_tables()

    def create_tables(self):
        """Create the necessary tables if they don't exist"""
        with sqlite3.connect(self.db_file) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    password TEXT NOT NULL,
                    email TEXT UNIQUE NOT NULL,
                    is_admin INTEGER DEFAULT 0
                )
            """)
            conn.commit()

    def hash_password(self, password):
        """Hash the password using SHA-256"""
        return hashlib.sha256(password.encode()).hexdigest()

    def add_user(self, username, password, email, is_admin=0):
        """Adds a new user to the database"""
        hashed_password = self.hash_password(password)
        try:
            with sqlite3.connect(self.db_file) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO users (username, password, email, is_admin)
                    VALUES (?, ?, ?, ?)""",
                    (username, hashed_password, email, is_admin)
                )
                conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False  # User already exists

    def remove_user(self, username):
        """Removes a user from the database"""
        with sqlite3.connect(self.db_file) as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM users WHERE username = ?", (username,))
            conn.commit()
            return cursor.rowcount > 0  # True if user was deleted

    def get_all_users(self):
        """Retrieves all users"""
        with sqlite3.connect(self.db_file) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT username, email, is_admin FROM users")
            users = cursor.fetchall()
            return [{"username": user[0], "email": user[1], "is_admin": user[2]} for user in users]

    def update_user(self, old_username, new_username, new_email):
        """Updates user details"""
        with sqlite3.connect(self.db_file) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE users 
                SET username = ?, email = ? 
                WHERE username = ?""",
                (new_username, new_email, old_username)
            )
            conn.commit()
            return cursor.rowcount > 0  # True if update was successful
