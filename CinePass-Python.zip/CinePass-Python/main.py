from utils.console import Console
from controllers.main_controller import MainController

def main():
    controller = MainController()
    controller.run()

if __name__ == "__main__":
    main()
